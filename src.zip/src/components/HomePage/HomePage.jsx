import React from 'react'
import "./HomePage.css";
export default function HomePage() {
  return (
    <div className='bgImg'>
exrctvbn
    </div>
  )
}
