import './App.css';
import HomePage from './components/HomePage/HomePage';

function App() {
  return (
    <div className="App">
     <HomePage/>
    </div>
  );
}

export default App;
